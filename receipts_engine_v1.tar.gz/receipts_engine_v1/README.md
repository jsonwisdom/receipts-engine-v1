# Receipts Engine v1

Deterministic reference kernel.

## Verify
```bash
python3 impl/verify.py --test vectors/test_vectors.json
```

Expected:
```text
ALL PASS (3/3)
```

## Seal Process
After files are final:
```bash
tar -czf receipts_engine_v1.tar.gz receipts_engine_v1/
sha256sum receipts_engine_v1.tar.gz
```

Publish the hash in this README and attach the tarball to release `v1.0-sealed`.
